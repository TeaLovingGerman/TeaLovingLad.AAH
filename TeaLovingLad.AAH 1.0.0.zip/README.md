# TeaLovingLad.AAH
AAH (Awesome Accessory Hoard) contains miscellaneous accessories to dress up with.
All accessories are compatible with most modded species!

This mod adds the following accessories:
("*" includes colour variants)
- Axe
- Grass Blade
- Smoking Pipe
- Three-Leaf Clover
- Four-Leaf Clover
- Belts *
- Neck-worn Bandana *
- Leg Wraps *
- Arm Wraps *

![alt text](https://imgur.com/qUQP6v0.png)
